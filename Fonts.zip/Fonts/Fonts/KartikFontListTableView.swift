//
//  KartikFontListTableView.swift
//  Fonts
//
//  Created by macadmin on 2016-11-22.
//  Copyright © 2016 LambtonCollege. All rights reserved.
//

import UIKit

class KartikFontListTableView: UITableView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
